import random
import numpy as np
from deap import base, creator, tools, gp

# =============================================================================
# SINGLE-TREE EVOLUTION
# =============================================================================

def setup_toolbox(pset, pop_size, cxpb=0.5, mutpb=0.2, tournsize=3):
    """Configures a standard DEAP toolbox for single-tree evolution."""
    # Handle creator singleton safely
    if not hasattr(creator, "FitnessMax"):
        creator.create("FitnessMax", base.Fitness, weights=(1.0,))
    if not hasattr(creator, "Individual"):
        creator.create("Individual", gp.PrimitiveTree, fitness=creator.FitnessMax)

    toolbox = base.Toolbox()
    toolbox.register("expr", gp.genHalfAndHalf, pset=pset, min_=1, max_=3)
    toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.expr)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)
    toolbox.register("compile", gp.compile, pset=pset)
    toolbox.register("mate", gp.cxOnePoint)
    toolbox.register("mutate", gp.mutUniform, expr=toolbox.expr, pset=pset)
    toolbox.register("select", tools.selTournament, tournsize=tournsize)

    return toolbox


def run_single_tree_evolution(toolbox, evaluate_fn, config):
    """
    Runs the standard single-tree evolutionary loop.

    Parameters
    ----------
    toolbox : deap.base.Toolbox
        Configured toolbox from setup_toolbox().
    evaluate_fn : callable
        Signature: evaluate_fn(individual, config) -> (fitness,).
    config : dict
        Must contain POP_SIZE, MAX_GENS, CXPB, MUTPB, HOF_SIZE, SEED.

    Returns
    -------
    best_individual : creator.Individual
    history : dict
        Keys: max_igss, avg_igss, uc_scores, d_scores, fossil_record.
    """
    random.seed(config["SEED"])
    np.random.seed(config["SEED"])

    pop = toolbox.population(n=config["POP_SIZE"])
    hof = tools.HallOfFame(config.get("HOF_SIZE", 1))
    history = {
        "max_igss": [],
        "avg_igss": [],
        "uc_scores": [],
        "d_scores": [],
        "fossil_record": {}
    }

    # Evaluate initial population
    fitnesses = [evaluate_fn(ind, config) for ind in pop]
    for ind, fit in zip(pop, fitnesses):
        ind.fitness.values = fit
    hof.update(pop)

    for gen in range(1, config["MAX_GENS"] + 1):
        offspring = toolbox.select(pop, len(pop))
        offspring = list(map(toolbox.clone, offspring))

        cxpb = config.get("CXPB", 0.5)
        mutpb = config.get("MUTPB", 0.2)

        for child1, child2 in zip(offspring[::2], offspring[1::2]):
            if random.random() < cxpb:
                toolbox.mate(child1, child2)
                del child1.fitness.values
                del child2.fitness.values

        for mutant in offspring:
            if random.random() < mutpb:
                toolbox.mutate(mutant)
                del mutant.fitness.values

        invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
        fitnesses = [evaluate_fn(ind, config) for ind in invalid_ind]
        for ind, fit in zip(invalid_ind, fitnesses):
            ind.fitness.values = fit

        pop[:] = offspring
        hof.update(pop)

        # Elitism
        if config.get("HOF_SIZE", 1) > 0:
            pop[-1] = toolbox.clone(hof[0])

        best_in_gen = tools.selBest(pop, k=1)[0]
        history["max_igss"].append(best_in_gen.sim_igss)
        history["avg_igss"].append(np.mean([ind.sim_igss for ind in pop]))
        history["uc_scores"].append(best_in_gen.sim_uc)
        history["d_scores"].append(best_in_gen.sim_d)

        if gen % 10 == 0 or gen == 1:
            history["fossil_record"][gen] = str(best_in_gen)
            print(f" > Gen {gen:02d} | iGSS: {best_in_gen.sim_igss:.1f} | UC: {best_in_gen.sim_uc:.1f} | UD: {best_in_gen.sim_d:.1f}")

    return hof[0], history


# =============================================================================
# DUAL-TREE EVOLUTION
# =============================================================================

def setup_dual_tree_toolbox(pset_action, pset_assess, pop_size, cxpb=0.5, mutpb=0.2, tournsize=3):
    """Configures a DEAP toolbox for dual-tree co-evolution."""
    if not hasattr(creator, "FitnessMax"):
        creator.create("FitnessMax", base.Fitness, weights=(1.0,))
    if not hasattr(creator, "Individual"):
        creator.create("Individual", list, fitness=creator.FitnessMax)

    toolbox = base.Toolbox()
    toolbox.register("expr_action", gp.genHalfAndHalf, pset=pset_action, min_=1, max_=3)
    toolbox.register("expr_assess", gp.genHalfAndHalf, pset=pset_assess, min_=1, max_=3)

    def init_individual(container, func1, func2):
        return container([gp.PrimitiveTree(func1()), gp.PrimitiveTree(func2())])

    toolbox.register("individual", init_individual, creator.Individual,
                     toolbox.expr_action, toolbox.expr_assess)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)
    toolbox.register("compile_action", gp.compile, pset=pset_action)
    toolbox.register("compile_assess", gp.compile, pset=pset_assess)

    def cxTwoTrees(ind1, ind2):
        if random.random() < 0.5:
            ind1[0], ind2[0] = gp.cxOnePoint(ind1[0], ind2[0])
        else:
            ind1[1], ind2[1] = gp.cxOnePoint(ind1[1], ind2[1])
        return ind1, ind2

    def mutTwoTrees(individual):
        if random.random() < 0.5:
            individual[0], = gp.mutUniform(individual[0], expr=toolbox.expr_action, pset=pset_action)
        else:
            individual[1], = gp.mutUniform(individual[1], expr=toolbox.expr_assess, pset=pset_assess)
        return individual,

    toolbox.register("mate", cxTwoTrees)
    toolbox.register("mutate", mutTwoTrees)
    toolbox.register("select", tools.selTournament, tournsize=tournsize)

    return toolbox


def run_dual_tree_evolution(toolbox, evaluate_fn, config):
    """
    Runs the dual-tree evolutionary loop.

    evaluate_fn signature: evaluate_fn(individual, config) -> (fitness,)
    individual is a list [action_tree, assess_tree].
    """
    random.seed(config["SEED"])
    np.random.seed(config["SEED"])

    pop = toolbox.population(n=config["POP_SIZE"])
    hof = tools.HallOfFame(config.get("HOF_SIZE", 1))
    history = {
        "max_igss": [],
        "avg_igss": [],
        "uc_scores": [],
        "d_scores": [],
        "fossil_record": {}
    }

    fitnesses = [evaluate_fn(ind, config) for ind in pop]
    for ind, fit in zip(pop, fitnesses):
        ind.fitness.values = fit
    hof.update(pop)

    for gen in range(1, config["MAX_GENS"] + 1):
        offspring = toolbox.select(pop, len(pop))
        offspring = list(map(toolbox.clone, offspring))

        cxpb = config.get("CXPB", 0.5)
        mutpb = config.get("MUTPB", 0.2)

        for child1, child2 in zip(offspring[::2], offspring[1::2]):
            if random.random() < cxpb:
                toolbox.mate(child1, child2)
                del child1.fitness.values
                del child2.fitness.values

        for mutant in offspring:
            if random.random() < mutpb:
                toolbox.mutate(mutant)
                del mutant.fitness.values

        invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
        fitnesses = [evaluate_fn(ind, config) for ind in invalid_ind]
        for ind, fit in zip(invalid_ind, fitnesses):
            ind.fitness.values = fit

        pop[:] = offspring
        hof.update(pop)

        if config.get("HOF_SIZE", 1) > 0:
            pop[-1] = toolbox.clone(hof[0])

        best_in_gen = tools.selBest(pop, k=1)[0]
        history["max_igss"].append(best_in_gen.sim_igss)
        history["avg_igss"].append(np.mean([ind.sim_igss for ind in pop]))
        history["uc_scores"].append(best_in_gen.sim_uc)
        history["d_scores"].append(best_in_gen.sim_d)

        if gen % 10 == 0 or gen == 1:
            history["fossil_record"][gen] = f"ACT: {best_in_gen[0]} | ASSESS: {best_in_gen[1]}"
            print(f" > Gen {gen:02d} | iGSS: {best_in_gen.sim_igss:.1f} | UC: {best_in_gen.sim_uc:.1f} | UD: {best_in_gen.sim_d:.1f}")

    return hof[0], history


# =============================================================================
# TRIPLE-TREE EVOLUTION (Future-proofing)
# =============================================================================

def setup_triple_tree_toolbox(pset_action, pset_assess1, pset_assess2, pop_size,
                              cxpb=0.5, mutpb=0.2, tournsize=3):
    """Configures a DEAP toolbox for triple-tree co-evolution."""
    if not hasattr(creator, "FitnessMax"):
        creator.create("FitnessMax", base.Fitness, weights=(1.0,))
    if not hasattr(creator, "Individual"):
        creator.create("Individual", list, fitness=creator.FitnessMax)

    toolbox = base.Toolbox()
    toolbox.register("expr_action", gp.genHalfAndHalf, pset=pset_action, min_=1, max_=3)
    toolbox.register("expr_assess1", gp.genHalfAndHalf, pset=pset_assess1, min_=1, max_=3)
    toolbox.register("expr_assess2", gp.genHalfAndHalf, pset=pset_assess2, min_=1, max_=3)

    def init_individual(container, func1, func2, func3):
        return container([gp.PrimitiveTree(func1()), gp.PrimitiveTree(func2()), gp.PrimitiveTree(func3())])

    toolbox.register("individual", init_individual, creator.Individual,
                     toolbox.expr_action, toolbox.expr_assess1, toolbox.expr_assess2)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)
    toolbox.register("compile_action", gp.compile, pset=pset_action)
    toolbox.register("compile_assess1", gp.compile, pset=pset_assess1)
    toolbox.register("compile_assess2", gp.compile, pset=pset_assess2)

    def cxThreeTrees(ind1, ind2):
        roll = random.random()
        if roll < 0.33:
            ind1[0], ind2[0] = gp.cxOnePoint(ind1[0], ind2[0])
        elif roll < 0.66:
            ind1[1], ind2[1] = gp.cxOnePoint(ind1[1], ind2[1])
        else:
            ind1[2], ind2[2] = gp.cxOnePoint(ind1[2], ind2[2])
        return ind1, ind2

    def mutThreeTrees(individual):
        roll = random.random()
        if roll < 0.33:
            individual[0], = gp.mutUniform(individual[0], expr=toolbox.expr_action, pset=pset_action)
        elif roll < 0.66:
            individual[1], = gp.mutUniform(individual[1], expr=toolbox.expr_assess1, pset=pset_assess1)
        else:
            individual[2], = gp.mutUniform(individual[2], expr=toolbox.expr_assess2, pset=pset_assess2)
        return individual,

    toolbox.register("mate", cxThreeTrees)
    toolbox.register("mutate", mutThreeTrees)
    toolbox.register("select", tools.selTournament, tournsize=tournsize)

    return toolbox


def run_triple_tree_evolution(toolbox, evaluate_fn, config):
    """
    Runs the triple-tree evolutionary loop.

    evaluate_fn signature: evaluate_fn(individual, config) -> (fitness,)
    individual is a list [action_tree, assess1_tree, assess2_tree].
    """
    random.seed(config["SEED"])
    np.random.seed(config["SEED"])

    pop = toolbox.population(n=config["POP_SIZE"])
    hof = tools.HallOfFame(config.get("HOF_SIZE", 1))
    history = {
        "max_igss": [],
        "avg_igss": [],
        "uc_scores": [],
        "d_scores": [],
        "fossil_record": {}
    }

    fitnesses = [evaluate_fn(ind, config) for ind in pop]
    for ind, fit in zip(pop, fitnesses):
        ind.fitness.values = fit
    hof.update(pop)

    for gen in range(1, config["MAX_GENS"] + 1):
        offspring = toolbox.select(pop, len(pop))
        offspring = list(map(toolbox.clone, offspring))

        cxpb = config.get("CXPB", 0.5)
        mutpb = config.get("MUTPB", 0.2)

        for child1, child2 in zip(offspring[::2], offspring[1::2]):
            if random.random() < cxpb:
                toolbox.mate(child1, child2)
                del child1.fitness.values
                del child2.fitness.values

        for mutant in offspring:
            if random.random() < mutpb:
                toolbox.mutate(mutant)
                del mutant.fitness.values

        invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
        fitnesses = [evaluate_fn(ind, config) for ind in invalid_ind]
        for ind, fit in zip(invalid_ind, fitnesses):
            ind.fitness.values = fit

        pop[:] = offspring
        hof.update(pop)

        if config.get("HOF_SIZE", 1) > 0:
            pop[-1] = toolbox.clone(hof[0])

        best_in_gen = tools.selBest(pop, k=1)[0]
        history["max_igss"].append(best_in_gen.sim_igss)
        history["avg_igss"].append(np.mean([ind.sim_igss for ind in pop]))
        history["uc_scores"].append(best_in_gen.sim_uc)
        history["d_scores"].append(best_in_gen.sim_d)

        if gen % 10 == 0 or gen == 1:
            history["fossil_record"][gen] = f"ACT: {best_in_gen[0]} | MEM: {best_in_gen[1]} | STAND: {best_in_gen[2]}"
            print(f" > Gen {gen:03d} | iGSS: {best_in_gen.sim_igss:.1f} | UC: {best_in_gen.sim_uc:.1f} | D: {best_in_gen.sim_d:.1f}")

    return hof[0], history
