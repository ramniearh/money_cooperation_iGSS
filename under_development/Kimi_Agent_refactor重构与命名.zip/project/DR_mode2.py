"""
Direct Reciprocity Mode 2 (Memory Assessment Search)
Evolves an assessment rule that decides whether to add/remove agents from memory,
while the action rule remains hardcoded to strict Tit-for-Tat.
"""

import operator
import random
import numpy as np
from deap import base, creator, tools, gp
from datetime import datetime

from config import QUICK_TEST_CONFIG, get_scenario_batches
from utilities import simplify_rule, evaluate_truth_table, log_results_to_csv, generate_dashboard
from igss_engine import setup_toolbox, run_single_tree_evolution
from abm_base import BaseAgent

import mesa

# =============================================================================
# 1. EXPERIMENT-SPECIFIC GP SETUP
# =============================================================================
def random_constant():
    return random.choice([-10, -1, 0, 1, 10])

pset_assessment = gp.PrimitiveSet("AssessmentRule_DR", 2)
pset_assessment.renameArguments(ARG0='DonorAction', ARG1='DonorInMemory')
pset_assessment.addPrimitive(operator.add, 2)
pset_assessment.addPrimitive(operator.sub, 2)
pset_assessment.addPrimitive(operator.mul, 2)
pset_assessment.addEphemeralConstant("rand_const_ass", random_constant)

# =============================================================================
# 2. AGENT CLASS (subclass BaseAgent)
# =============================================================================
class CoopAgent(BaseAgent):
    def __init__(self, model, agent_type="iGSS-Agent"):
        super().__init__(model, agent_type)
        self.memory = set()

    def evaluate_partner(self, partner):
        result = super().evaluate_partner(partner)
        if result is not None:
            return result

        return partner.unique_id not in self.memory

# =============================================================================
# 3. MODEL CLASS
# =============================================================================
class CooperationModel(mesa.Model):
    def __init__(self, igss_rule, config, control_mode=False):
        super().__init__()
        self.igss_rule = igss_rule
        self.config = config
        self.control_mode = control_mode
        self.benefit = config["BENEFIT_TO_COST_RATIO"] * config["COST"]
        self.cost = config["COST"]

        target_agent = "Control-Agent" if control_mode else "iGSS-Agent"

        for _ in range(config["NUM_IGSS"]): CoopAgent(self, target_agent)
        for _ in range(config["NUM_UC"]): CoopAgent(self, "Unconditional Cooperator")
        for _ in range(config.get("NUM_UD", config.get("NUM_D", 10))): CoopAgent(self, "Unconditional Defector")

    def step(self):
        agents = list(self.agents)
        random.shuffle(agents)

        for donor in agents:
            possible_recipients = [a for a in agents if a.unique_id != donor.unique_id]
            recipient = random.choice(possible_recipients)

            donor_action = donor.evaluate_partner(recipient)
            self.resolve(donor=donor, recipient=recipient, cooperates=donor_action)

    def resolve(self, donor, recipient, cooperates):
        if cooperates:
            donor.payoff -= self.cost
            recipient.payoff += self.benefit

        if self.control_mode:
            if not cooperates:
                recipient.memory.add(donor.unique_id)
            else:
                if donor.unique_id in recipient.memory:
                    recipient.memory.remove(donor.unique_id)
        else:
            action_val = 1 if cooperates else 0
            donor_in_mem = 1 if donor.unique_id in recipient.memory else 0

            decision_score = self.igss_rule(action_val, donor_in_mem)

            if decision_score > 0:
                recipient.memory.add(donor.unique_id)
            else:
                recipient.memory.discard(donor.unique_id)

    def get_fitness_by_type(self):
        fitness_data = {}
        for a_type in ["iGSS-Agent", "Control-Agent", "Unconditional Cooperator", "Unconditional Defector"]:
            type_agents = [a for a in self.agents if a.agent_type == a_type]
            if type_agents:
                fitness_data[a_type] = sum(a.payoff for a in type_agents) / len(type_agents)
            else:
                fitness_data[a_type] = 0
        return fitness_data

# =============================================================================
# 4. EVALUATION FUNCTION
# =============================================================================
def evaluate_rule(individual, config):
    func_assessment = toolbox.compile(expr=individual)

    tot_igss, tot_uc, tot_ud = 0, 0, 0
    runs = 3
    for _ in range(runs):
        m = CooperationModel(igss_rule=func_assessment, config=config)
        for _ in range(config["NUM_ROUNDS"]): m.step()

        fits = m.get_fitness_by_type()
        tot_igss += fits["iGSS-Agent"]
        tot_uc += fits["Unconditional Cooperator"]
        tot_ud += fits["Unconditional Defector"]

    individual.sim_igss = tot_igss / runs
    individual.sim_uc = tot_uc / runs
    individual.sim_d = tot_ud / runs

    tax = len(individual) * config["PARSIMONY_TAX"]
    final_score = individual.sim_igss - tax
    return final_score,

# =============================================================================
# 5. CONTROL BASELINE
# =============================================================================
def get_control_baseline(config):
    tot_control = 0
    runs = 5
    for _ in range(runs):
        m = CooperationModel(igss_rule=None, config=config, control_mode=True)
        for _ in range(config["NUM_ROUNDS"]): m.step()
        tot_control += m.get_fitness_by_type()["Control-Agent"]
    return tot_control / runs

# =============================================================================
# 6. EXECUTION BLOCK
# =============================================================================
if __name__ == "__main__":

    DR_MEMORY_DICT = {
        (False, False, True, True): "Strict Ledger (TFT Base)",
        (True, True, True, True): "Paranoid (Remember Everyone)",
        (False, False, False, False): "Amnesia (Remember No One)",
        (False, True, True, True): "Unforgiving (Grim Trigger)",
        (False, True, False, True): "Sticky Memory (Ignore actions entirely)"
    }

    variables = ["DonorAction", "DonorInMemory"]

    # -------------------------------------------------------------------------
    # OPTION A: SINGLE VISUAL TEST
    # -------------------------------------------------------------------------
    """
    print("\n--- RUNNING SINGLE VISUAL TEST ---")
    config = QUICK_TEST_CONFIG
    toolbox = setup_toolbox(pset_assessment, config["POP_SIZE"])
    best_rule, history = run_single_tree_evolution(toolbox, evaluate_rule, config)
    control_fit = get_control_baseline(config)

    simp_assessment = str(simplify_rule(str(best_rule), variables))
    raw_tuple = evaluate_truth_table(simp_assessment, variables)
    identified_strategy = DR_MEMORY_DICT.get(raw_tuple, f"Novel Rule: {raw_tuple}")

    run_log = {
        "Timestamp": datetime.now().strftime("%Y-%m-%d_%H-%M"),
        "Machine_ID": "Local_VSCode",
        "Run_ID": f"DR2_TEST_{datetime.now().strftime('%H%M%S')}",
        "Mode": "Direct Reciprocity Mode 2 (Memory Ledger Search)",
        **config,
        "Best_Rule_Raw": str(best_rule),
        "Best_Rule_SymPy": simp_assessment,
        "Identified_Strategy": identified_strategy,
        "iGSS_Max_Fitness": round(history["max_igss"][-1], 2),
        "iGSS_Avg_Fitness": round(history["avg_igss"][-1], 2),
        "UC_Fitness": round(history["uc_scores"][-1], 2),
        "UD_Fitness": round(history["d_scores"][-1], 2),
        "Control_Baseline": round(control_fit, 2),
        "Manual_Validation": ""
    }

    log_results_to_csv(run_log, filename="results_DR_Mode2.csv")
    generate_dashboard(best_rule, history, run_log, save_only=False)
    """

    # -------------------------------------------------------------------------
    # OPTION B: BATCH SCENARIO
    # -------------------------------------------------------------------------

    batches = get_scenario_batches()
    print(f"\n--- STARTING BATCH EXECUTION: {len(batches)} TOTAL RUNS QUEUED ---")

    for i, config in enumerate(batches):
        print(f"\n[Run {i+1}/{len(batches)} | {config['CONFIG_GROUP']} Rep {config.get('REPETITION', 1)}] Seed: {config.get('SEED', 42)}")

        print("Initializing Direct Reciprocity [MODE 2 - Memory Assessment Search]...")
        control_fit = get_control_baseline(config)
        print(f"Control Baseline (Strict Memory Ledger) established at: {control_fit:.2f} average payoff.")

        toolbox = setup_toolbox(pset_assessment, config["POP_SIZE"])
        best_rule, history = run_single_tree_evolution(toolbox, evaluate_rule, config)

        simp_assessment = str(simplify_rule(str(best_rule), variables))
        raw_tuple = evaluate_truth_table(simp_assessment, variables)
        identified_strategy = DR_MEMORY_DICT.get(raw_tuple, f"Novel Rule: {raw_tuple}")

        run_log = {
            "Timestamp": datetime.now().strftime("%Y-%m-%d_%H-%M"),
            "Machine_ID": "Local_VSCode",
            "Run_ID": f"DR2_{config.get('CONFIG_GROUP', 'Default')}_R{config.get('REPETITION', 1)}",
            "Mode": "Direct Reciprocity Mode 2 (Memory Ledger Search)",
            **config,
            "Best_Rule_Raw": str(best_rule),
            "Best_Rule_SymPy": simp_assessment,
            "Identified_Strategy": identified_strategy,
            "iGSS_Max_Fitness": round(history["max_igss"][-1], 2),
            "iGSS_Avg_Fitness": round(history["avg_igss"][-1], 2),
            "UC_Fitness": round(history["uc_scores"][-1], 2),
            "UD_Fitness": round(history["d_scores"][-1], 2),
            "Control_Baseline": round(control_fit, 2),
            "Manual_Validation": ""
        }

        log_results_to_csv(run_log, filename="results_DR_Mode2.csv")
        if config.get("GENERATE_FIGURES", False):
            generate_dashboard(best_rule, history, run_log, save_only=True)

    print("\n[✓] Batch complete! Check results_DR_Mode2.csv.")
