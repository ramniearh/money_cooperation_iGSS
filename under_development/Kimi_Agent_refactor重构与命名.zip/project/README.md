# iGSS: inverse Generative Social Science

A minimal agent-based modelling framework that uses genetic programming (DEAP) to evolve cooperation strategies in multi-type agent ecologies. Each scenario is a self-contained script; shared infrastructure handles the evolutionary loop, leaving the scientifically interesting mechanics visible and local.

## Quick Start

Run any scenario directly from the project root:

```bash
python DR_mode1.py          # Direct Reciprocity, single-tree action rule
python IR_mode3.py          # Indirect Reciprocity, dual-tree co-evolution
python money_mode1.py       # Monetary action search
```

Every scenario contains two execution options:
- **Option A (Single Visual Test):** Uncomment the block, run once, see plots on screen.
- **Option B (Batch Scenario):** Sweeps the parameter grid defined in `config.py` and appends results to a mode-specific CSV.

## File Guide

### Infrastructure (read once, do not modify)

| File | Purpose |
|------|---------|
| `config.py` | Central defaults, parameter sweep grid, and batch generator. Edit `SCENARIO_GRID` to define sweeps. |
| `igss_engine.py` | Shared DEAP evolutionary loop: single-tree, dual-tree, and triple-tree toolboxes + runners. No Mesa, no scenario logic. |
| `abm_base.py` | Minimal `BaseAgent` with payoff and type dispatch only. Subclassed per scenario for memory, standing, tokens, etc. |
| `utilities.py` | SymPy rule simplification, truth-table evaluation, CSV logging, fitness plots, and tree visualisation. |

### Scenarios (one file = one complete experiment)

**Naming convention:** `[Mechanism]_mode[N].py` — Mechanism = DR (Direct Reciprocity), IR (Indirect Reciprocity), MONEY; Mode = 1 (action search), 2 (assessment search), 3 (co-evolution).

| File | What It Does | Evolved | Hardcoded Control | Key State |
|------|-------------|---------|-------------------|-----------|
| `DR_mode1.py` | Action rule: cooperate if partner is in memory? | 1 tree (memory signal) | Tit-for-Tat | `memory` (set) |
| `DR_mode2.py` | Assessment rule: add to memory ledger after interaction? | 1 tree (action, memory) | Strict memory ledger | `memory` (set) |
| `DR_mode3.py` | Co-evolve action + assessment rules jointly | 2 trees | Tit-for-Tat | `memory` (set) |
| `IR_mode1.py` | Action rule: cooperate if partner has good standing? | 1 tree (standing signal) | Strict Discriminator (Standing) | `standing` (int) |
| `IR_mode2.py` | Assessment rule: update standing after observing action? | 1 tree (action, recipient standing) | Standing Norm | `standing` (int) |
| `IR_mode3.py` | Co-evolve action + standing assessment jointly | 2 trees | Strict Discriminator | `standing` (int) |
| `mixed_DRIR_mode3.py` | Mixed ecology: agents use memory AND standing simultaneously | 2 trees | Hybrid AND (memory + standing) | `memory`, `standing` |
| `money_mode1.py` | Action rule: cooperate based on token holdings? | 1 tree (partner token, my token) | Accumulating Capitalist | `token` (int) |

## Agent Types

Every scenario contains three fixed types and one evolved type:

| Type | Behaviour |
|------|-----------|
| iGSS-Agent | Executes the evolved GP rule(s). The only type whose behaviour changes across generations. |
| Unconditional Cooperator | Always cooperates. Baseline for altruism. |
| Unconditional Defector | Always defects. Baseline for exploitation. |
| Control-* | A hardcoded strategy (varies by scenario: TFT, Standing, etc.). Establishes the theoretical baseline fitness. |

## Architecture Principles

1. **Self-contained scenarios.** Open any `*_mode*.py` file and you see the full experiment: GP setup, agent class, model class, resolution logic, evaluation, and execution. No cross-file scenario imports.
2. **Extracted engine.** `igss_engine.py` contains only invariant DEAP machinery: toolbox setup, population initialisation, selection/crossover/mutation loop, elitism, and history tracking.
3. **Minimal base class.** `BaseAgent` handles only payoff and type dispatch. All state (memory, standing, tokens) lives in scenario-specific subclasses.
4. **Future-proof.** Triple-tree functions exist for 5-type joint ecologies. The `BaseAgent` subclassing pattern accommodates any combination of state variables.

## Configuration

Edit `config.py` to change defaults or define parameter sweeps:

```python
DEFAULTS = {
    "BENEFIT_TO_COST_RATIO": 5,   # b/c ratio
    "COST": 1,                    # cost of cooperation
    "NUM_IGSS": 10,               # evolved agents
    "NUM_UC": 10,                 # unconditional cooperators
    "NUM_UD": 10,                 # unconditional defectors
    "NUM_ROUNDS": 100,            # interaction rounds per evaluation
    "POP_SIZE": 40,               # GP population size
    "MAX_GENS": 100,              # evolutionary generations
    "PARSIMONY_TAX": 0.1,         # tree-size penalty
    "GENERATE_FIGURES": False,    # skip PNG generation in batch mode
}
```

Set `GENERATE_FIGURES = True` to enable fitness plots and tree diagrams during batch execution (default is off for speed).

## Outputs

Each scenario writes to a mode-specific CSV (`results_DR_Mode1.csv`, etc.) with one row per run. The `figures/` directory holds plots when figure generation is enabled. All CSVs share the same column schema so they can be concatenated for cross-scenario analysis.

## Dependencies

- Python 3.9+
- `deap` (genetic programming)
- `mesa` (agent-based modelling)
- `numpy`, `sympy`, `networkx`, `matplotlib` (utilities and visualisation)
