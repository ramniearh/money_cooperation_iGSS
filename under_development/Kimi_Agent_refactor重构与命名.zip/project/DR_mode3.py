"""
Direct Reciprocity Mode 3 (Co-Evolution)
Dual-tree co-evolution of action rules and memory-assessment rules for direct reciprocity.
"""

import operator
import random
import numpy as np
from deap import base, creator, tools, gp
from datetime import datetime

from config import QUICK_TEST_CONFIG, get_scenario_batches
from utilities import simplify_rule, evaluate_truth_table, log_results_to_csv, generate_dashboard
from igss_engine import setup_dual_tree_toolbox, run_dual_tree_evolution
from abm_base import BaseAgent

import mesa

# =============================================================================
# 1. EXPERIMENT-SPECIFIC GP SETUP
# =============================================================================
def random_constant():
    return random.choice([-10, -1, 0, 1, 10])

# --- Tree 1: Action Rule (Behavior based on Memory) ---
pset_action = gp.PrimitiveSet("ActionRule_DR", 1)
pset_action.renameArguments(ARG0='PartnerInMemory')
pset_action.addPrimitive(operator.add, 2)
pset_action.addPrimitive(operator.sub, 2)
pset_action.addPrimitive(operator.mul, 2)
pset_action.addEphemeralConstant("rand_const_act", random_constant)

# --- Tree 2: Assessment Rule (Updating the Memory Ledger) ---
pset_assessment = gp.PrimitiveSet("AssessmentRule_DR", 2)
pset_assessment.renameArguments(ARG0='DonorAction', ARG1='DonorInMemory')
pset_assessment.addPrimitive(operator.add, 2)
pset_assessment.addPrimitive(operator.sub, 2)
pset_assessment.addPrimitive(operator.mul, 2)
pset_assessment.addEphemeralConstant("rand_const_ass", random_constant)

# =============================================================================
# 2. AGENT CLASS (subclass BaseAgent)
# =============================================================================
class CoopAgent(BaseAgent):
    def __init__(self, model, agent_type="iGSS-Agent"):
        super().__init__(model, agent_type)
        self.memory = set()

    def evaluate_partner(self, partner):
        result = super().evaluate_partner(partner)
        if result is not None:
            return result

        if self.agent_type == "Control-Agent":
            return partner.unique_id not in self.memory

        in_memory_val = 1 if partner.unique_id in self.memory else 0
        decision_score = self.model.igss_action_rule(in_memory_val)
        return decision_score > 0

# =============================================================================
# 3. MODEL CLASS
# =============================================================================
class CooperationModel(mesa.Model):
    def __init__(self, igss_action_rule, igss_assessment_rule, config, control_mode=False):
        super().__init__()
        self.igss_action_rule = igss_action_rule
        self.igss_assessment_rule = igss_assessment_rule
        self.config = config
        self.control_mode = control_mode
        self.benefit = config["BENEFIT_TO_COST_RATIO"] * config["COST"]
        self.cost = config["COST"]

        target_agent = "Control-Agent" if control_mode else "iGSS-Agent"

        for _ in range(config["NUM_IGSS"]): CoopAgent(self, target_agent)
        for _ in range(config["NUM_UC"]): CoopAgent(self, "Unconditional Cooperator")
        for _ in range(config.get("NUM_UD", config.get("NUM_D", 10))): CoopAgent(self, "Unconditional Defector")

    def step(self):
        agents = list(self.agents)
        random.shuffle(agents)

        for donor in agents:
            possible_recipients = [a for a in agents if a.unique_id != donor.unique_id]
            recipient = random.choice(possible_recipients)

            donor_action = donor.evaluate_partner(recipient)
            self.resolve(donor=donor, recipient=recipient, cooperates=donor_action)

    def resolve(self, donor, recipient, cooperates):
        if cooperates:
            donor.payoff -= self.cost
            recipient.payoff += self.benefit

        if self.control_mode:
            if not cooperates:
                recipient.memory.add(donor.unique_id)
            else:
                if donor.unique_id in recipient.memory:
                    recipient.memory.remove(donor.unique_id)
        else:
            action_val = 1 if cooperates else 0
            donor_in_mem = 1 if donor.unique_id in recipient.memory else 0

            decision_score = self.igss_assessment_rule(action_val, donor_in_mem)
            if decision_score > 0:
                recipient.memory.add(donor.unique_id)
            else:
                recipient.memory.discard(donor.unique_id)

    def get_fitness_by_type(self):
        fitness_data = {}
        for a_type in ["iGSS-Agent", "Control-Agent", "Unconditional Cooperator", "Unconditional Defector"]:
            type_agents = [a for a in self.agents if a.agent_type == a_type]
            if type_agents:
                fitness_data[a_type] = sum(a.payoff for a in type_agents) / len(type_agents)
            else:
                fitness_data[a_type] = 0
        return fitness_data

# =============================================================================
# 4. EVALUATION FUNCTION
# =============================================================================
def evaluate_rules(individual, config):
    func_action = toolbox.compile_action(expr=individual[0])
    func_assessment = toolbox.compile_assess(expr=individual[1])

    tot_igss, tot_uc, tot_ud = 0, 0, 0
    runs = 3
    for _ in range(runs):
        m = CooperationModel(igss_action_rule=func_action, igss_assessment_rule=func_assessment, config=config)
        for _ in range(config["NUM_ROUNDS"]): m.step()

        fits = m.get_fitness_by_type()
        tot_igss += fits["iGSS-Agent"]
        tot_uc += fits["Unconditional Cooperator"]
        tot_ud += fits["Unconditional Defector"]

    individual.sim_igss = tot_igss / runs
    individual.sim_uc = tot_uc / runs
    individual.sim_d = tot_ud / runs

    tax = (len(individual[0]) + len(individual[1])) * config["PARSIMONY_TAX"]
    final_score = individual.sim_igss - tax
    return final_score,

# =============================================================================
# 5. CONTROL BASELINE
# =============================================================================
def get_control_baseline(config):
    tot_control = 0
    runs = 5
    for _ in range(runs):
        m = CooperationModel(igss_action_rule=None, igss_assessment_rule=None, config=config, control_mode=True)
        for _ in range(config["NUM_ROUNDS"]): m.step()
        tot_control += m.get_fitness_by_type()["Control-Agent"]
    return tot_control / runs

# =============================================================================
# 6. EXECUTION BLOCK
# =============================================================================
if __name__ == "__main__":

    DR_ACTION_DICT = {
        (False, True): "Tit-for-Tat",
        (True, True): "Unconditional Cooperator (ALL-C)",
        (False, False): "Unconditional Defector (ALL-D)",
        (True, False): "Anti-Tit-for-Tat"
    }

    DR_MEMORY_DICT = {
        (False, False, True, True): "Strict Ledger (TFT Base)",
        (True, True, True, True): "Paranoid (Remember Everyone)",
        (False, False, False, False): "Amnesia (Remember No One)",
        (True, False, True, True): "Unforgiving (Grim Trigger)",
        (True, False, True, False): "Sticky Memory (Ignore actions entirely)"
    }

    action_vars = ["PartnerInMemory"]
    assess_vars = ["DonorAction", "DonorInMemory"]

    # -------------------------------------------------------------------------
    # OPTION A: SINGLE VISUAL TEST
    # -------------------------------------------------------------------------
    """
    print("\n--- RUNNING SINGLE VISUAL TEST ---")
    config = QUICK_TEST_CONFIG
    toolbox = setup_dual_tree_toolbox(pset_action, pset_assessment, config["POP_SIZE"])
    best_rule, history = run_dual_tree_evolution(toolbox, evaluate_rules, config)
    control_fit = get_control_baseline(config)

    simp_action = str(simplify_rule(str(best_rule[0]), action_vars))
    act_tuple = evaluate_truth_table(simp_action, action_vars)
    identified_action = DR_ACTION_DICT.get(act_tuple, f"Novel Act: {act_tuple}")

    simp_assessment = str(simplify_rule(str(best_rule[1]), assess_vars))
    ass_tuple = evaluate_truth_table(simp_assessment, assess_vars)
    identified_assessment = DR_MEMORY_DICT.get(ass_tuple, f"Novel Mem: {ass_tuple}")

    run_log = {
        "Timestamp": datetime.now().strftime("%Y-%m-%d_%H-%M"),
        "Machine_ID": "Local_VSCode",
        "Run_ID": f"DR3_TEST_{datetime.now().strftime('%H%M%S')}",
        "Mode": "Direct Reciprocity Mode 3 (Co-Evolution)",
        **config,
        "Best_Act_Raw": str(best_rule[0]),
        "Best_Act_SymPy": simp_action,
        "Identified_Action": identified_action,
        "Best_Ass_Raw": str(best_rule[1]),
        "Best_Ass_SymPy": simp_assessment,
        "Identified_Assessment": identified_assessment,
        "iGSS_Max_Fitness": round(history["max_igss"][-1], 2),
        "iGSS_Avg_Fitness": round(history["avg_igss"][-1], 2),
        "UC_Fitness": round(history["uc_scores"][-1], 2),
        "UD_Fitness": round(history["d_scores"][-1], 2),
        "Control_Baseline": round(control_fit, 2)
    }

    log_results_to_csv(run_log, filename="results_DR_Mode3.csv")
    generate_dashboard(best_rule, history, run_log, save_only=False)
    """

    # -------------------------------------------------------------------------
    # OPTION B: BATCH SCENARIO
    # -------------------------------------------------------------------------

    batches = get_scenario_batches()
    print(f"\n--- STARTING BATCH EXECUTION: {len(batches)} TOTAL RUNS QUEUED ---")

    for i, config in enumerate(batches):
        print(f"\n[Run {i+1}/{len(batches)} | {config['CONFIG_GROUP']} Rep {config.get('REPETITION', 1)}] Seed: {config.get('SEED', 42)}")

        print("Initializing Direct Reciprocity [MODE 3 - Co-Evolution Search]...")
        control_fit = get_control_baseline(config)
        print(f"Control Baseline (Tit-for-Tat) established at: {control_fit:.2f} average payoff.")

        toolbox = setup_dual_tree_toolbox(pset_action, pset_assessment, config["POP_SIZE"])
        best_rule, history = run_dual_tree_evolution(toolbox, evaluate_rules, config)

        simp_action = str(simplify_rule(str(best_rule[0]), action_vars))
        act_tuple = evaluate_truth_table(simp_action, action_vars)
        identified_action = DR_ACTION_DICT.get(act_tuple, f"Novel Act: {act_tuple}")

        simp_assessment = str(simplify_rule(str(best_rule[1]), assess_vars))
        ass_tuple = evaluate_truth_table(simp_assessment, assess_vars)
        identified_assessment = DR_MEMORY_DICT.get(ass_tuple, f"Novel Mem: {ass_tuple}")

        run_log = {
            "Timestamp": datetime.now().strftime("%Y-%m-%d_%H-%M"),
            "Machine_ID": "Local_VSCode",
            "Run_ID": f"DR3_{config.get('CONFIG_GROUP', 'Default')}_R{config.get('REPETITION', 1)}",
            "Mode": "Direct Reciprocity Mode 3 (Co-Evolution)",
            **config,
            "Best_Act_Raw": str(best_rule[0]),
            "Best_Act_SymPy": simp_action,
            "Identified_Action": identified_action,
            "Best_Ass_Raw": str(best_rule[1]),
            "Best_Ass_SymPy": simp_assessment,
            "Identified_Assessment": identified_assessment,
            "iGSS_Max_Fitness": round(history["max_igss"][-1], 2),
            "iGSS_Avg_Fitness": round(history["avg_igss"][-1], 2),
            "UC_Fitness": round(history["uc_scores"][-1], 2),
            "UD_Fitness": round(history["d_scores"][-1], 2),
            "Control_Baseline": round(control_fit, 2)
        }

        log_results_to_csv(run_log, filename="results_DR_Mode3.csv")
        if config.get("GENERATE_FIGURES", False):
            generate_dashboard(best_rule, history, run_log, save_only=True)

    print("\n[✓] Batch complete! Check results_DR_Mode3.csv.")
