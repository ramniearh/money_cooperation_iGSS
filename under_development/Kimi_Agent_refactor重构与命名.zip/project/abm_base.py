import mesa

class BaseAgent(mesa.Agent):
    def __init__(self, model, agent_type="iGSS-Agent"):
        super().__init__(model)
        self.agent_type = agent_type
        self.payoff = 0

    def evaluate_partner(self, partner):
        if self.agent_type == "Unconditional Cooperator":
            return True
        if self.agent_type == "Defector":
            return False
        return None
